let aliencolor: string = "green";
if (aliencolor=="green")
{
    console.log("You earned 5 points.");
}
else
{
    console.log("You earned 10 points.");
}
