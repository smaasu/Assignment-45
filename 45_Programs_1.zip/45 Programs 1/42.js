var magicians = ['Alex', 'Ben', 'Cruz'];
function make_great(magician) {
    for (var i = 0; i < magician.length; i++)
        magicians[i] = "Great " + magicians[i];
    //return magician[];
}
make_great(magicians);
function show_magicians(magician) {
    for (var _i = 0, magician_1 = magician; _i < magician_1.length; _i++) {
        var names = magician_1[_i];
        console.log(names);
    }
}
show_magicians(magicians);
