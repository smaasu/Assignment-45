function describe_city (city: string, country: string = "Earth"): string
{
    return `The ${city} is a state in a  ${country}`;
}
console.log(describe_city("Karachi", "Pakistan"));
console.log(describe_city("Jeruselum", "Palestine"));
console.log(describe_city("Kashmir",));

