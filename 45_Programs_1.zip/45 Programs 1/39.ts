function city_names (city: string, country: string): string
{
    return `${city}, ${country}`;
}
console.log(city_names("Paris", "France"));
console.log(city_names("Ankara", "Turkey"));
console.log(city_names("Dehli", "India"));