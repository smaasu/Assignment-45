let alien_color: string = "green";
if (alien_color=="green")
{
    console.log("You earned 5 points.");
}

if (alien_color=="red")
{
}
