console.clear()
function make_tshirt (size: string, text: string): string
{
    if (size=="Large" || size=="Medium") 
        return "The size of the Shirt is: " + size + " \nAnd the text is: I love TypeScript";
    else 
        return "The size of the Shirt is: " + size + " \nAnd the text is: " + text;

}
console.log(make_tshirt("Large", "Earth is flat for stupids"));
console.log("\n");
console.log(make_tshirt("Medium", "Earth is flat for stupids"));
console.log("\n");
console.log(make_tshirt("Very Small", "Earth is flat for stupids"));


