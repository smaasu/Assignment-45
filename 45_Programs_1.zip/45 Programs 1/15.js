var Guests = ["Sam Altman", "Jeff Bezos", "Elon Musk"];
console.log("They cant make dinner!");
for (var _i = 0, Guests_1 = Guests; _i < Guests_1.length; _i++) {
    var invitaions = Guests_1[_i];
    console.log("Mr. " + invitaions);
}
Guests.push("Bill Gates");
Guests.push("Sundar Pichaye");
console.log("\nBut they can!");
for (var invi = 0; invi < Guests.length - 3; invi++)
    console.log("Mr. " + Guests[invi + 3]);
