interface album
{
    artist: string;
    name: string;
    track?: number;
}

function make_album(artist: string, name: string, track?: number): album
{
return track!== undefined ? { artist, name, track } :  { artist, name };
}

let album1 = make_album("Ali Zafar","Huqa Pani");
console.log(album1);

let album2 = make_album("M.Rafi","Chaidhvin Ka Chand");
console.log(album2);

let album3 = make_album("Kishore Kumar","Aradhan",6);
console.log(album3);