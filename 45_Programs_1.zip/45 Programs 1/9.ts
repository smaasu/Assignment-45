let favnum: number = 1;
console.log("My favourite number is "+favnum);