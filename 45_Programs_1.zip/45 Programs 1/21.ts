interface Countries 
{
    name: string;
    population: string;
    capital: string;
    continent: string;
}
let  Countries: Countries[] = [
    {
        name: "Pakistan", 
        population: "30 Millions",
        capital: "Islamabad",
        continent: "Asia"
    }
];
console.log(Countries[0]);
console.log(Countries[0].capital);