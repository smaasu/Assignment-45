var alienscolor = "green";
console.log("When Alien's color is Green :");
if (alienscolor == "green") {
    console.log("You earned 5 points.");
}
else if (alienscolor == "yellow") {
    console.log("You earned 10 points.");
}
else if (alienscolor == "red") {
    console.log("You earned 15 points.");
}
alienscolor = "yellow";
console.log("\nWhen Alien's color is Yellow :");
if (alienscolor == "green") {
    console.log("You earned 5 points.");
}
else if (alienscolor == "yellow") {
    console.log("You earned 10 points.");
}
else if (alienscolor == "red") {
    console.log("You earned 15 points.");
}
alienscolor = "red";
console.log("\nWhen Alien's color is Red :");
if (alienscolor == "green") {
    console.log("You earned 5 points.");
}
else if (alienscolor == "yellow") {
    console.log("You earned 10 points.");
}
else if (alienscolor == "red") {
    console.log("You earned 15 points.");
}
