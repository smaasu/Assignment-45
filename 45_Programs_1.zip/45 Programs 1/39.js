function city_names(city, country) {
    return "".concat(city, ", ").concat(country);
}
console.log(city_names("Paris", "France"));
console.log(city_names("Ankara", "Turkey"));
console.log(city_names("Dehli", "India"));
