var user = ["Ibraheem", "Yaqoob", "Yusuf", ""];
for (var i = 0; i < user.length; i++)
    if (user[i] === '')
        console.log("\nNo user found, We need to find some users!");
    else
        console.log("Hey! " + user[i]);
