console.log("I'm inviting two guests");
