var animals = ["cat", "dog", "elephant", "lion"];
for (var _i = 0, animals_1 = animals; _i < animals_1.length; _i++) {
    var types = animals_1[_i];
    console.log(types + " is a Four leg Animal");
}
console.log("These are Animals and Humans are also Social Animal (HomoSapiens)");
console.log("These are four leg Animals but Humans are not four leg Animal");
