interface Car
{
    manufacturer: string;
    model: string;
    // year: number;
    // color: string;
    [key: string]: any;
}
function CarsStoredInfo (manufacturer: string, model: string, ...extras: [string, any][]): Car 
{
    const info: Car = {manufacturer, model};
    extras.forEach(([key, value]) => { info[key] = value });
    return info;
}
function printCarInfo (info: Car): void
{
    for (let key in info){
        if (info.hasOwnProperty(key)){
            console.log(key,":", info[key]);}}
}
const car1: Car = CarsStoredInfo("Toyota", "Corolla",["color","red"], ["year", 2024]);
const car2: Car = CarsStoredInfo("Honda", "50CC",["color","black"], ["year", 1987]);
printCarInfo(car2);
