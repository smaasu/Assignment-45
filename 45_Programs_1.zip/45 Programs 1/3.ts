let text: string = "All is Well That Ends Well";

// let t: string = ;
console.log(("In Uppercase : "+text).toUpperCase());
console.log(("In Lowercase : "+text).toLowerCase());
//let z: string = text.replace(/\b\w/g, c => c.`/(\w+)/.toUpperCase());
function toTitleCase(input: string): string 
{
    return input.toLowerCase().replace(/\b\w/g, c => c. toUpperCase());
}
const a : string= toTitleCase(text);
console.log(a);