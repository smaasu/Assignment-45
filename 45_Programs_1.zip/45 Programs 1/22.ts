let Boys: string[] = ["Ali", "Ahmad","Akbar","Awais","Alam"];
console.log(Boys[10]);//This will show error as undefined