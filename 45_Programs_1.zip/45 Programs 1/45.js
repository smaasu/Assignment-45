function CarsStoredInfo(manufacturer, model) {
    var extras = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        extras[_i - 2] = arguments[_i];
    }
    var info = { manufacturer: manufacturer, model: model };
    extras.forEach(function (_a) {
        var key = _a[0], value = _a[1];
        info[key] = value;
    });
    return info;
}
function printCarInfo(info) {
    for (var key in info) {
        if (info.hasOwnProperty(key)) {
            console.log(key, ":", info[key]);
        }
    }
}
var car1 = CarsStoredInfo("Toyota", "Corolla", ["color", "red"], ["year", 2024]);
var car2 = CarsStoredInfo("Honda", "50CC", ["color", "black"], ["year", 1987]);
console.log(car1);
console.log(car2);
printCarInfo(car2);
