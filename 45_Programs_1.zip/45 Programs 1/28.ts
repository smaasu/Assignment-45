let age:number = 36;
if (age<2)
    console.log("He is baby!");
else if (age<4)
    console.log("He is toddler!");
else if (age<13)
    console.log("He is kid!");
else if (age<20)
    console.log("He is teenager!");
else if (age<65)
    console.log("He is adult!");
else
    console.log("He is elder!");




