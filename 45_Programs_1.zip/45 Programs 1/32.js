var current_user = ["Alice", "Bob", "Smith", "John", "Peter", "Taylor"];
var new_user = ["Armstrong", "Barry", "Cliff", "Dart", "Elton", "Taylor"];
//console.log(new_user[4]);
for (var _i = 0, new_user_1 = new_user; _i < new_user_1.length; _i++) {
    var num = new_user_1[_i];
    var a = false;
    console.log(num + ":");
    for (var i = 0; i <= current_user.length; i++) {
        if (num == current_user[i])
            a = true;
    }
    if (a == true)
        console.log("username already exists");
    else
        console.log("username is available!");
}
