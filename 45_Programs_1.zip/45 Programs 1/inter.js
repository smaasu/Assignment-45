var Country1 = [
    {
        name: "Pakistan",
        population: "30 Millions",
        capital: "Islamabad",
        continent: "Asia"
    },
    {
        name: "India",
        population: "300 Millions",
        capital: "Dehli",
        continent: "Asia"
    }
];
var Country2 = [
    {
        name: "India",
        population: "300 Millions",
        capital: "Dehli",
        continent: "Asia"
    }
];
console.log(Country1[0]);
console.log(Country1[1].capital);
