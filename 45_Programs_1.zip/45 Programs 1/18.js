var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var places = ["Makkah", "Madina", "Al'Aqsa", "Deep Blue Sea", "Neom City"];
console.log("\nOriginal list in orignal order\n");
for (var _i = 0, places_1 = places; _i < places_1.length; _i++) {
    var visits = places_1[_i];
    console.log(visits);
}
console.log("\nOriginal list in alphabetical order\n");
var ord = __spreadArray([], places, true).sort();
for (var v = 0; v < places.length; v++) {
    console.log(ord[v]);
}
console.log("\nOriginal list in orginal order\n");
for (var _a = 0, places_2 = places; _a < places_2.length; _a++) {
    var visits = places_2[_a];
    console.log(visits);
}
console.log("\nOriginal list in reversed order\n");
ord = __spreadArray([], ord, true).reverse();
for (var v = 0; v < places.length; v++) {
    console.log(ord[v]);
}
console.log("\nOriginal list in orignal order\n");
for (var _b = 0, places_3 = places; _b < places_3.length; _b++) {
    var visits = places_3[_b];
    console.log(visits);
}
console.log("\nReversed list in original order\n");
for (var _c = 0, _d = places.reverse(); _c < _d.length; _c++) {
    var visits = _d[_c];
    console.log(visits);
}
console.log("\nReversed list back in original order\n");
for (var _e = 0, _f = places.sort().reverse(); _e < _f.length; _e++) {
    var visits = _f[_e];
    console.log(visits);
}
console.log("\nReversed list in original order\n" + places.reverse());
console.log("\nReversed list back in original order\n" + places.reverse() + "\n");
