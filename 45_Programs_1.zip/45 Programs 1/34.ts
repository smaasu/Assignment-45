let pizza:string[] = ["BarBQ","Chicken Tikka","Pepperoni" ];
console.clear();

for (let types of pizza) 
{
    console.log(types);
}
console.log("\n");

for (let types of pizza) 
    console.log("I like ",types," pizza");
console.log("\nI really love Pizza");

