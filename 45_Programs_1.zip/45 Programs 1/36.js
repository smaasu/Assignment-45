console.clear();
function make_shirt(size, text) {
    return "The size of the Shirt is: " + size + " \nAnd the text is:\n" + text;
}
console.log(make_shirt("Medium", "Earth is flat for stupids"));
