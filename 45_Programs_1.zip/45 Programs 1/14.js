var Guest = ["Sam Altman", "Jeff Bezos", "Elon Musk"];
for (var _i = 0, Guest_1 = Guest; _i < Guest_1.length; _i++) {
    var invitaions = Guest_1[_i];
    console.log("Join us for unforgettable evening! Mr. " + invitaions);
}
