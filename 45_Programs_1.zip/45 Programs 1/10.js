// 16 February 2024
var fvnum = 1;
console.log("My favourite number is " + fvnum);
// Store your favorite number in a variable. Then, using that variable, create a message that reveals your favorite number
// 16 February 2024
var dv = "Abdullah";
console.log("Hey " + dv + "!, Would you like to learn some GenAI today?");
// Store a person’s name in a variable, and print a message to that person
