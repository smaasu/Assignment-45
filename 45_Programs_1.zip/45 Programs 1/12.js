var naams = ["Abdullah", "Abdurrahman", "Riazuddin", "Shoaib", "Maqsood"];
console.log("List of My Friend :");
for (var _i = 0, naams_1 = naams; _i < naams_1.length; _i++) {
    var k = naams_1[_i];
    console.log("congratulations " + k);
}
