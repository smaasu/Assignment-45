let x: number = 4;
let clr: string = "red";

for (let x:number = -4; x<5 ;x++)
console.log(x+" is "+ (x<0 ? "Number is Positive" : "Number is Negative"))
    console.log("\nCar color is "+(clr=='red' ? "Red" : "Green"));