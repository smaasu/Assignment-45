var alien_color = "green";
//let h:number =5;
if (alien_color == "green") {
    console.log("You earned 5 points.");
}
if (alien_color == "red") {
}
