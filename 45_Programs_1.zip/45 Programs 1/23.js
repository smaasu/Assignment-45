var x = 4;
var clr = "red";
for (var x_1 = -4; x_1 < 5; x_1++)
    console.log(x_1 + " is " + (x_1 < 0 ? "Number is Positive" : "Number is Negative"));
console.log("\nCar color is " + (clr == 'red' ? "Red" : "Green"));
