var naam = "\n\tSalahuddin Ayyubi\t\n";
console.log("Simple : " + naam);
console.log("Stripped : " + naam.trim());
