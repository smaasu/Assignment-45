var favnum = 1;
console.log("My favourite number is " + favnum);
