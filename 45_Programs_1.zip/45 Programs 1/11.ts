let nams: string[] = ["Abdullah","Abdurrahman","Safeel","Samiyan","Wahaj"];
console.log("List of My Friend :");
for (let k of names)
{console.log(k);}
