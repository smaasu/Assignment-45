var users = ["admin", "Aon", "Ali", "Umar", "Abu"];
for (var _i = 0, users_1 = users; _i < users_1.length; _i++) {
    var names = users_1[_i];
    console.log(names == "admin" ? "Hello Admin, would you like to see a status report" : "Hello " + names + " Thank you for logging in again");
}
