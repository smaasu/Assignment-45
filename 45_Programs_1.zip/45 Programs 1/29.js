var favorite_fruits = ["apple", "orange", "banana", "pomegranate", "berry", "peach", "pear"];
for (var _i = 0, favorite_fruits_1 = favorite_fruits; _i < favorite_fruits_1.length; _i++) {
    var choice = favorite_fruits_1[_i];
    if (choice == "peach")
        console.log("Peach is my favorite fruit");
}
