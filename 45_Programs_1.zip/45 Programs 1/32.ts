let current_user: string[] = ["Alice", "Bob", "Smith","John", "Peter", "Taylor"];
let new_user: string[] = ["Armstrong", "Barry","Cliff", "Dart", "Elton","Taylor"];
//console.log(new_user[4]);
for (let num of new_user) 
{
    let a:boolean=false;
    console.log(num+":");
    for (let i = 0; i <= current_user.length; i++)
    {
        if (num==current_user[i])
        a=true;
    }
    if (a==true)
        console.log("username already exists");
    else
        console.log("username is available!");
}

