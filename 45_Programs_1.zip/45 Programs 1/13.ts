let transport: string[] = ["Boot","Wheel Shoes","Bicycle","Car","Drone Car","Helicopter","Jet","Rocket"];
for (let mediums of transport)
console.log("I used travel through "+mediums)