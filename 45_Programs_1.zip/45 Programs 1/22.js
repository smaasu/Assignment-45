var Boys = ["Ali", "Ahmad", "Akbar", "Awais", "Alam"];
console.log(Boys[10]);
