var numbers = [];
for (var i = 1; i < 11; i++) {
    numbers.push(i);
    if (numbers[i - 1] == 1)
        console.log(numbers[i - 1] + "st");
    else if (numbers[i - 1] == 2)
        console.log(numbers[i - 1] + "nd");
    else if (numbers[i - 1] == 3)
        console.log(numbers[i - 1] + "rd");
    else
        console.log(numbers[i - 1] + "th");
}
