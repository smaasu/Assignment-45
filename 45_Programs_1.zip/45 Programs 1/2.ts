let dev:string = "Abdullah";
console.log("Hey "+dev+"!, Would you like to learn some GenAI today?");
