var Countries = [
    {
        name: "Pakistan",
        population: "30 Millions",
        capital: "Islamabad",
        continent: "Asia"
    }
];
console.log(Countries[0]);
console.log(Countries[0].capital);
