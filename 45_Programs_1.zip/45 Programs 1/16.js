var Guestss = ["Sam Altman", "Jeff Bezos", "Elon Musk"];
console.log("They cant make dinner!");
for (var _i = 0, Guestss_1 = Guestss; _i < Guestss_1.length; _i++) {
    var invitaions = Guestss_1[_i];
    console.log("Mr. " + invitaions);
}
Guestss.push("Bill Gates");
Guestss.push("Sundar Pichaye");
console.log("\nBut they can!");
console.log("Mr. " + Guestss[3]);
console.log("Mr. " + Guestss[4]);
Guestss.push("Warren Buffet");
Guestss.push("Satya Nandella");
Guestss.push("Ali Baba");
console.log("\nNew Guest are :");
for (var i = 0; i < 2; i++)
    console.log("Mr. " + Guestss[i + 5]);
