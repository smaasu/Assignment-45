let Guestsss: string[] = ["Sam Altman","Jeff Bezos","Elon Musk"];
Guestsss.push("Bill Gates");
Guestsss.push("Sundar Pichaye");
Guestsss.push("Warren Buffet");
Guestsss.push("Satya Nandella");
Guestsss.push("Ali Baba");

console.log("Guest List :");
for (let invitaions of Guestsss)
console.log("Mr. "+invitaions)

console.log("\nI accidentally send invitation to all my guests but later I realized that I have only two just Zingers left therefore I'm sending them apalogize message!\n");

for (let i=0 ;i<Guestsss.length-2; i++)
console.log("Mr. "+Guestsss[i]+", I would like confirmed you that upcoming party has been postponed");

console.log("\nBut!\n");

for (let i=0 ;i<2; i++)
console.log("Mr. "+Guestsss[Guestsss.length-2+i]+", You are still invited in upcoming party !");

