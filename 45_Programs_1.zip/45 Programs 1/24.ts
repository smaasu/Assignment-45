let Suspect = "Sam"

console.log("Suspect is" + (Suspect=="Sam" ?" Sam" : "not Sam"));
console.log("He is" + (Suspect!=="Sam" ?" Shen" : " not Shen"));

let percents:number = 96;
console.log("Percents is" + (percents>89 ? " Above" : " Below")+" 90%");
console.log("Percents is" + (!(percents>89) ? " Below" : " Above")+" 90%");

let boy1:number = 75;
let boy2:number = 85;
let boy3:number = 85;

console.log(boy1==boy2 && boy1==boy3 ? "Marks of all boys is same" : "Their marks are not same");
console.log(boy1==boy2 || boy2==boy3 ? "Two boys got same marks" : "All Boy got differnet marks are not same");

let maaarks: number[] = [88,99];
console.log(maaarks[0]==maaarks[1] ? "same marks" : " differnet marks");
