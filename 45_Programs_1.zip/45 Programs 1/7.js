console.log("Sum : 7+1 = \t" + Math.pow(2, 3));
console.log("Difference : 9-1 = \t" + Math.pow(2, 3));
console.log("Product : 2 X 4 = \t" + 2 * 4);
console.log("Quotient : 16/2 = \t" + 16 / 2);
