let Guests: string[] = ["Sam Altman","Jeff Bezos","Elon Musk"];
console.log("They cant make dinner!");
for (let invitaions of Guests)
console.log("Mr. "+invitaions);
Guests.push("Bill Gates");
Guests.push("Sundar Pichaye");
console.log("\nBut they can!");
for (let invi:number=0 ;invi<Guests.length-3; invi++)
console.log("Mr. "+Guests[invi+3]);

