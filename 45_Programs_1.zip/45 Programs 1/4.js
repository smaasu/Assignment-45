console.log("M.Ali Jinnah once uttered, \"Nothing Can Undo Pakistan\"");
