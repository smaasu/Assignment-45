let animals:string[] = ["Cat", "Dog", "Elephant", "Lion"];
for (let types of animals) 
    console.log(types+" is a Four leg Animal");
    console.log("These are Animals and Humans are also Social Animal (HomoSapiens)");
    console.log("These are four leg Animals but Humans are not four leg Animal");