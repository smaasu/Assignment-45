var transport = ["Boot", "Wheel Shoes", "Bicycle", "Car", "Drone Car", "Helicopter", "Jet", "Rocket"];
for (var _i = 0, transport_1 = transport; _i < transport_1.length; _i++) {
    var mediums = transport_1[_i];
    console.log("I used travel through " + mediums);
}
