var Magicians = ['Alex', 'Ben', 'Cruz'];
var Tricker = ['Alex', 'Ben', 'Cruz'];
function make_Great(magicians) {
    for (var i = 0; i < magicians.length; i++)
        magicians[i] = "Great " + magicians[i];
    return magicians;
}
Tricker = make_Great(Tricker);
function show_Magicians(magician) {
    for (var _i = 0, magician_1 = magician; _i < magician_1.length; _i++) {
        var names = magician_1[_i];
        console.log(names);
    }
}
show_Magicians(Magicians);
show_Magicians(Tricker);
