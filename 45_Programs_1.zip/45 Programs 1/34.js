var pizza = ["BarBQ", "Chicken Tikka", "Pepperoni"];
console.clear();
for (var _i = 0, pizza_1 = pizza; _i < pizza_1.length; _i++) {
    var types = pizza_1[_i];
    console.log(types);
}
console.log("\n");
for (var _a = 0, pizza_2 = pizza; _a < pizza_2.length; _a++) {
    var types = pizza_2[_a];
    console.log("I like ", types, " pizza");
}
console.log("\nI really love Pizza");
