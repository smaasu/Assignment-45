var text = "All is Well That Ends Well";
// let t: string = ;
console.log(("In Uppercase : " + text).toUpperCase());
console.log(("In Lowercase : " + text).toLowerCase());
//let z: string = text.replace(/\b\w/g, c => c.`/(\w+)/.toUpperCase());
function toTitleCase(input) {
    return input.toLowerCase().replace(/\b\w/g, function (c) { return c.toUpperCase(); });
}
var a = toTitleCase(text);
console.log(a);
