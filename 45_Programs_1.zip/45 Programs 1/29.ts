let favorite_fruits: string[] = ["apple", "orange", "banana", "pomegranate", "berry", "peach", "pear"];
for(let choice of favorite_fruits)
    if (choice=="peach") 
        console.log("Peach is my favorite fruit");