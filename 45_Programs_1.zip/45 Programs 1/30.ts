let users: string[] = ["admin","Aon","Ali","Umar","Abu"];
for (let names of users)
{
    console.log(names=="admin" ? "Hello Admin, would you like to see a status report?" : "Hello "+names+" Thank you for logging in again");
}
