let Sandwich: string[] = ["Bread", "Egg", "Kecthup", "Black Pepper"];
let Qorma: string[] = ["Chicken", "Shan Masala", "Tomato", "Oil"];
let Bharta: string[] = ["Potato", "Sweet Water", "Chat Masala"];
function ingredents (items: string[]):void
{
    console.log("\nThe ingredients required for the cooking are listed below : ");
    for (let list of items)
    console.log(list);
} 
ingredents(Sandwich);
ingredents(Qorma);
ingredents(Bharta);
