let famous_person: string = " \"Nothing Can Undo Pakistan\"";
let message: string = "Muhammad Ali Jinnah once uttered,";
console.log(message+famous_person);