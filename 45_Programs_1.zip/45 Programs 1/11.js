var names = ["Abdullah", "Abdurrahman", "Safeel", "Samiyan", "Wahaj"];
console.log("List of My Friend :");
for (var _i = 0, names_1 = names; _i < names_1.length; _i++) {
    var k = names_1[_i];
    console.log(k);
}
