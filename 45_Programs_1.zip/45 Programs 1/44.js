var Sandwich = ["Bread", "Egg", "Kecthup", "Black Pepper"];
var Qorma = ["Chicken", "Shan Masala", "Tomato", "Oil"];
var Bharta = ["Potato", "Sweet Water", "Chat Masala"];
function ingredents(items) {
    console.log("\nThe ingredients required for the cooking are listed below : ");
    for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
        var list = items_1[_i];
        console.log(list);
    }
}
ingredents(Sandwich);
ingredents(Qorma);
ingredents(Bharta);
