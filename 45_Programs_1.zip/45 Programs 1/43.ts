let Magicians: string[] = ['Alex', 'Ben', 'Cruz'];
let Tricker: string[] = ['Alex', 'Ben', 'Cruz'];

function make_Great (magicians: string[]): string[]
{
    for (let i=0; i<magicians.length; i++)
    magicians[i] = "Great "+magicians[i];
    return magicians;
}
Tricker = make_Great (Tricker);

function show_Magicians (magician: string[]): void
{
    for (let names of magician)
        console.log(names);
}

show_Magicians(Magicians);
show_Magicians(Tricker);