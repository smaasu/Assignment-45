console.log(2+6);
console.log(4+4);
console.log(8+0);
console.log(3+5);