let cities: string[] = ["Karachi","Lahore","London","Paris","Moscow","Mumbai","Dehli"];
for (var i = 0; i < cities.length; i++)
{
    console.log(cities[i]);
}