let places: string[] = ["Makkah", "Madina", "Al'Aqsa", "Deep Blue Sea", "Neom City"];

console.log("\nOriginal list in orignal order\n");
for (let visits of places) 
{
    console.log(visits);
}

console.log("\nOriginal list in alphabetical order\n");
let ord: string[] = [...places].sort();
for (let v=0; v<places.length; v++) 
{
    console.log(ord[v]);
}


console.log("\nOriginal list in orginal order\n");
for (let visits of places) 
{
    console.log(visits);
}

console.log("\nOriginal list in reversed order\n");

ord = [...ord].reverse();
for (let v=0; v<places.length; v++) 
{
    console.log(ord[v]);
}

console.log("\nOriginal list in orignal order\n");
for (let visits of places) 
{
    console.log(visits);
}

console.log("\nReversed list in original order\n");
for (let visits of places.reverse()) 
{
    console.log(visits);
}

console.log("\nReversed list back in original order\n");
for (let visits of places.sort().reverse()) 
{
    console.log(visits);
}

console.log("\nReversed list in original order\n"+places.reverse());

console.log("\nReversed list back in original order\n"+places.reverse()+"\n");
