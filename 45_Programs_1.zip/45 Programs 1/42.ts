let magicians: string[] = ['Alex', 'Ben', 'Cruz'];
function make_great (magician: string[]): void
{
    for (let i=0; i<magician.length; i++)
    magicians[i] = "Great "+magicians[i];
    //return magician[];
}
make_great(magicians);
function show_magicians (magician: string[]): void
{

    for (let names of magician)
        console.log(names);
}
show_magicians(magicians);
