var Magician = ['Alex', 'Ben', 'Cruz'];
function show_magician(magician) {
    for (var _i = 0, magician_1 = magician; _i < magician_1.length; _i++) {
        var names = magician_1[_i];
        console.log(names);
    }
}
show_magician(Magician);
