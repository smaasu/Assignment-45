var famous_person = " \"Nothing Can Undo Pakistan\"";
var message = "Muhammad Ali Jinnah once uttered,";
console.log(message + famous_person);
