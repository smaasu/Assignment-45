let Magician: string[] = ['Alex', 'Ben', 'Cruz'];
function show_magician (magician: string[]): void
{

    for (let names of magician)
        console.log(names);
}
show_magician(Magician);