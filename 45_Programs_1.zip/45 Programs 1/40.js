function make_album(artist, name, track) {
    return track !== undefined ? { artist: artist, name: name, track: track } : { artist: artist, name: name };
}
var album1 = make_album("Ali Zafar", "Huqa Pani");
console.log(album1);
var album2 = make_album("M.Rafi", "Chaidhvin Ka Chand");
console.log(album2);
var album3 = make_album("Kishore Kumar", "Aradhan", 6);
console.log(album3);
