let Guest: string[] = ["Sam Altman","Jeff Bezos","Elon Musk"];
for (let invitaions of Guest)
console.log("Join us for unforgettable evening! Mr. "+invitaions)

