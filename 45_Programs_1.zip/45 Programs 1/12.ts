let naams: string[] = ["Abdullah","Abdurrahman","Riazuddin","Shoaib","Maqsood"];
console.log("List of My Friend :");
for (let k of naams)
{
    console.log("congratulations "+k);
}
