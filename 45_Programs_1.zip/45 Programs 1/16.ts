let Guestss: string[] = ["Sam Altman","Jeff Bezos","Elon Musk"];
console.log("They cant make dinner!");
for (let invitaions of Guestss)
console.log("Mr. "+invitaions)

Guestss.push("Bill Gates");
Guestss.push("Sundar Pichaye");
console.log("\nBut they can!")
console.log("Mr. "+Guestss[3]);
console.log("Mr. "+Guestss[4]);

Guestss.push("Warren Buffet");
Guestss.push("Satya Nandella");
Guestss.push("Ali Baba");
console.log("\nNew Guest are :");
for (let i=0 ;i<2; i++)
console.log("Mr. "+Guestss[i+5]);


