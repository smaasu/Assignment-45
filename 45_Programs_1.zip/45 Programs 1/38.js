function describe_city(city, country) {
    if (country === void 0) { country = "Earth"; }
    return "The ".concat(city, " is a state in a  ").concat(country);
}
console.log(describe_city("Karachi", "Pakistan"));
console.log(describe_city("Jeruselum", "Palestine"));
console.log(describe_city("Kashmir"));
